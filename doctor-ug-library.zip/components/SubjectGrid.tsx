const subjects=[
"Anatomy",
"Physiology",
"Pathology",
"Pharma",
"Biochemistry"
];

export default function SubjectGrid(){

return(
<div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(150px,1fr))",gap:20,padding:20}}>

{subjects.map(s=>(
<div
key={s}
style={{padding:40,background:"#111",cursor:"pointer"}}>
{s}
</div>
))}

</div>
);
}
