export default function Hero(){
return(

<div style={{textAlign:"center",padding:"80px 20px"}}>

<h2 style={{fontSize:42,fontWeight:"bold"}}>
Future of Medical Learning
</h2>

<input
placeholder="Search books..."
style={{marginTop:20,padding:12,width:"90%",maxWidth:400}}
/>

</div>
);
}
