"use client";

import { signInWithPopup } from "firebase/auth";
import { auth, provider } from "@/services/firebase";

export default function Navbar(){

const login = async()=>{
 await signInWithPopup(auth,provider);
};

return(
<div style={{display:"flex",justifyContent:"space-between",padding:20}}>

<h1 style={{fontSize:24,fontWeight:"bold"}}>
DOCTOR UG
</h1>

<button
onClick={login}
style={{padding:"8px 16px"}}>
Login
</button>

</div>
);
}
