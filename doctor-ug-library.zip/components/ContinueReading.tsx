export default function ContinueReading(){

return(
<div style={{padding:20}}>

<h3 style={{fontSize:24,marginBottom:10}}>
Continue Reading
</h3>

<div style={{display:"flex",gap:10,overflowX:"auto"}}>

{[1,2,3].map(b=>(
<div
key={b}
style={{minWidth:160,padding:20,background:"#111"}}>
Book {b}
</div>
))}

</div>
</div>
);
}
