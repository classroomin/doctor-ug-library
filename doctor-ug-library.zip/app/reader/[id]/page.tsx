"use client";

export default function Reader(){

return(

<div style={{height:"100vh",background:"black"}}>

<iframe
src="/sample.pdf"
style={{width:"100%",height:"100%"}}
/>

</div>
);
}
