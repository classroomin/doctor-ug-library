"use client";

import {useState,useEffect} from "react";
import {auth,db,storage} from "@/services/firebase";
import {onAuthStateChanged} from "firebase/auth";

import {
collection,
addDoc,
getDocs,
deleteDoc,
doc
} from "firebase/firestore";

import {
ref,
uploadBytes,
getDownloadURL
} from "firebase/storage";

export default function Admin(){

const[user,setUser]=useState<any>(null);
const[isAdmin,setIsAdmin]=useState(false);

const[title,setTitle]=useState("");
const[file,setFile]=useState<any>(null);
const[premium,setPremium]=useState(false);

const[books,setBooks]=useState<any[]>([]);

useEffect(()=>{

onAuthStateChanged(auth,async(u)=>{
if(!u) return;

setUser(u);

const admins=await getDocs(collection(db,"admins"));

admins.forEach(a=>{
if(a.id===u.uid) setIsAdmin(true);
});

loadBooks();

});

},[]);

const loadBooks=async()=>{

const snap=await getDocs(collection(db,"books"));

let arr:any[]=[];

snap.forEach(d=>{
arr.push({id:d.id,...d.data()});
});

setBooks(arr);
};

const uploadBook=async()=>{

if(!file) return alert("select file");

const storageRef=
ref(storage,"books/"+Date.now()+"_"+file.name);

await uploadBytes(storageRef,file);

const url=await getDownloadURL(storageRef);

await addDoc(collection(db,"books"),{
title,
url,
premium
});

alert("Uploaded 🔥");

loadBooks();
};

const deleteBook=async(id:string)=>{

await deleteDoc(doc(db,"books",id));

loadBooks();
};

if(!user) return <div style={{padding:40}}>Login first</div>;
if(!isAdmin) return <div style={{padding:40}}>Not Admin</div>;

return(

<div style={{padding:40}}>

<h1 style={{fontSize:40,marginBottom:20}}>
ADMIN DASHBOARD
</h1>

<input
placeholder="Book title"
onChange={(e)=>setTitle(e.target.value)}
style={{padding:8,marginRight:10}}
/>

<input
type="file"
accept="application/pdf"
onChange={(e)=>setFile(e.target.files?.[0])}
/>

<label style={{marginLeft:10}}>
<input
type="checkbox"
onChange={()=>setPremium(!premium)}
/>
Premium
</label>

<button
onClick={uploadBook}
style={{marginLeft:10,padding:"8px 16px"}}>
Upload
</button>

<div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,200px)",gap:20,marginTop:40}}>

{books.map(b=>(
<div key={b.id} style={{background:"#111",padding:15}}>

<h3>{b.title}</h3>

<p>
{b.premium?"Premium":"Free"}
</p>

<button
onClick={()=>deleteBook(b.id)}
style={{color:"red"}}>
Delete
</button>

</div>
))}

</div>

</div>
);
}
