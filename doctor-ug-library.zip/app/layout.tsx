export const metadata = {
  title: "Doctor UG Library",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <head>
        <link rel="manifest" href="/manifest.json" />
      </head>
      <body style={{margin:0,background:"#020412",color:"white",fontFamily:"sans-serif"}}>
        {children}
      </body>
    </html>
  );
}
