import Navbar from "@/components/Navbar";
import Hero from "@/components/Hero";
import SubjectGrid from "@/components/SubjectGrid";
import ContinueReading from "@/components/ContinueReading";

export default function Home(){
return(
<main>
<Navbar/>
<Hero/>
<ContinueReading/>
<SubjectGrid/>
</main>
);
}
